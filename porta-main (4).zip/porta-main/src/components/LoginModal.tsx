import { X, Lock, User } from 'lucide-react';
import { useState } from 'react';

interface LoginModalProps {
  onClose: () => void;
  onLogin: (cpf: string) => void;
}

export default function LoginModal({ onClose, onLogin }: LoginModalProps) {
  const [cpf, setCpf] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPasswordField, setShowPasswordField] = useState(false);

  const ADMIN_CPF = '35928564805';
  const ADMIN_PASSWORD = 'valorant1';

  const formatCpf = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 3) {
      return numbers;
    } else if (numbers.length <= 6) {
      return `${numbers.slice(0, 3)}.${numbers.slice(3)}`;
    } else if (numbers.length <= 9) {
      return `${numbers.slice(0, 3)}.${numbers.slice(3, 6)}.${numbers.slice(6)}`;
    } else {
      return `${numbers.slice(0, 3)}.${numbers.slice(3, 6)}.${numbers.slice(6, 9)}-${numbers.slice(9, 11)}`;
    }
  };

  const handleCpfBlur = () => {
    const cleanCpf = cpf.replace(/\D/g, '');
    if (cleanCpf === ADMIN_CPF) {
      setShowPasswordField(true);
    } else {
      setShowPasswordField(false);
      setPassword('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanCpf = cpf.replace(/\D/g, '');

    if (cleanCpf.length !== 11) {
      setError('CPF deve ter 11 dígitos');
      return;
    }

    setIsLoading(true);

    if (cleanCpf === ADMIN_CPF) {
      if (password !== ADMIN_PASSWORD) {
        setError('Senha incorreta');
        setIsLoading(false);
        return;
      }
      onLogin(cleanCpf);
      return;
    }

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/customer-login`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ cpf: cleanCpf })
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'CPF não encontrado. Você precisa fazer um pedido primeiro.');
        setIsLoading(false);
        return;
      }

      onLogin(cleanCpf);
    } catch (err) {
      console.error('Erro ao fazer login:', err);
      setError('Erro ao acessar conta. Tente novamente.');
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-red-500 via-green-500 to-red-500"></div>

        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 z-20 bg-gray-100 hover:bg-gray-200 rounded-full p-2 transition-colors"
        >
          <X size={20} />
        </button>

        <div className="p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-red-500 to-green-500 rounded-full mb-4">
              <User size={32} className="text-white" />
            </div>
            <h2 className="text-3xl font-black text-gray-900 mb-2">
              Acessar Minha Conta
            </h2>
            <p className="text-gray-600">
              Digite o CPF usado na compra
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-gray-800 mb-2">
                CPF *
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  required
                  value={cpf}
                  onChange={(e) => setCpf(formatCpf(e.target.value))}
                  onBlur={handleCpfBlur}
                  maxLength={14}
                  className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white text-lg"
                  placeholder="000.000.000-00"
                />
              </div>
            </div>

            {showPasswordField && (
              <div>
                <label className="block text-sm font-bold text-gray-800 mb-2">
                  Senha de Administrador *
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white text-lg"
                    placeholder="Digite a senha"
                  />
                </div>
              </div>
            )}

            {error && (
              <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4">
                <p className="text-red-700 text-sm font-medium text-center">
                  {error}
                </p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-green-500 via-green-600 to-green-500 hover:from-green-600 hover:via-green-700 hover:to-green-600 text-white font-black text-lg py-4 rounded-xl shadow-xl transform hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {isLoading ? 'ACESSANDO...' : 'ACESSAR PEDIDOS'}
            </button>

            <div className="text-center">
              <p className="text-sm text-gray-600">
                Ainda não fez seu pedido?{' '}
                <button
                  type="button"
                  onClick={onClose}
                  className="text-green-600 font-bold hover:text-green-700 transition-colors"
                >
                  Comprar agora
                </button>
              </p>
            </div>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-center gap-2 text-gray-500 text-xs">
              <Lock size={14} />
              <span>Seus dados estão seguros e protegidos</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
