import { X, Package, Truck, CheckCircle, Clock, AlertCircle, Search, Edit2, Save, MapPin, Phone, Mail, Calendar, DollarSign, TrendingUp, ShoppingBag, Download, CheckSquare, Square } from 'lucide-react';
import { useState, useEffect } from 'react';

interface Order {
  id: string;
  transaction_id: string;
  status: string;
  amount: number;
  subtotal: number;
  shipping_fee: number;
  tracking_code: string | null;
  tracking_url: string | null;
  pix_qrcode: string | null;
  pix_expiration: string | null;
  created_at: string;
  paid_at: string | null;
  items: Array<{
    product_name: string;
    quantity: number;
    unit_price: number;
  }>;
  shipping_address: {
    address: string;
    number: string;
    complement: string | null;
    neighborhood: string;
    city: string;
    state: string;
    cep: string;
  };
  customer: {
    name: string;
    email: string;
    phone: string;
    cpf: string;
  };
}

interface AdminDashboardProps {
  onClose: () => void;
  onLogout: () => void;
}

export default function AdminDashboard({ onClose, onLogout }: AdminDashboardProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [editingTracking, setEditingTracking] = useState(false);
  const [newTrackingCode, setNewTrackingCode] = useState('');
  const [newTrackingUrl, setNewTrackingUrl] = useState('');
  const [editingStatus, setEditingStatus] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(new Set());
  const [selectAll, setSelectAll] = useState(false);

  useEffect(() => {
    loadAllOrders();
  }, []);

  useEffect(() => {
    filterOrders();
  }, [searchTerm, statusFilter, orders]);

  const loadAllOrders = async () => {
    setIsLoading(true);
    setError('');

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/get-all-orders`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
        }
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Erro ao carregar pedidos');
        setIsLoading(false);
        return;
      }

      setOrders(data.orders || []);
    } catch (err) {
      console.error('Erro ao carregar pedidos:', err);
      setError('Erro ao carregar pedidos. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const filterOrders = () => {
    let filtered = [...orders];

    if (statusFilter !== 'all') {
      filtered = filtered.filter(order => order.status === statusFilter);
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(order =>
        order.transaction_id.toLowerCase().includes(term) ||
        order.customer.name.toLowerCase().includes(term) ||
        order.customer.email.toLowerCase().includes(term) ||
        order.customer.cpf.includes(term)
      );
    }

    setFilteredOrders(filtered);
  };

  const toggleOrderSelection = (orderId: string) => {
    const newSelection = new Set(selectedOrderIds);
    if (newSelection.has(orderId)) {
      newSelection.delete(orderId);
    } else {
      newSelection.add(orderId);
    }
    setSelectedOrderIds(newSelection);
    setSelectAll(newSelection.size === filteredOrders.length);
  };

  const toggleSelectAll = () => {
    if (selectAll) {
      setSelectedOrderIds(new Set());
      setSelectAll(false);
    } else {
      const allIds = new Set(filteredOrders.map(order => order.id));
      setSelectedOrderIds(allIds);
      setSelectAll(true);
    }
  };

  const exportSelectedOrders = () => {
    const ordersToExport = orders.filter(order => selectedOrderIds.has(order.id));

    if (ordersToExport.length === 0) {
      alert('Selecione pelo menos um pedido para exportar');
      return;
    }

    let txtContent = '═══════════════════════════════════════════════════════════════════════\n';
    txtContent += '                    RELATÓRIO DE PEDIDOS - PORTA FELIZ                   \n';
    txtContent += '═══════════════════════════════════════════════════════════════════════\n\n';
    txtContent += `Data de Exportação: ${new Date().toLocaleString('pt-BR')}\n`;
    txtContent += `Total de Pedidos: ${ordersToExport.length}\n\n`;

    ordersToExport.forEach((order, index) => {
      txtContent += '─────────────────────────────────────────────────────────────────────────\n';
      txtContent += `PEDIDO #${index + 1}\n`;
      txtContent += '─────────────────────────────────────────────────────────────────────────\n\n';

      txtContent += '📋 INFORMAÇÕES DO PEDIDO:\n';
      txtContent += `   ID da Transação: ${order.transaction_id}\n`;
      txtContent += `   Data do Pedido: ${formatDate(order.created_at)}\n`;
      txtContent += `   Status: ${getStatusInfo(order.status).label}\n`;
      if (order.tracking_code) {
        txtContent += `   Código de Rastreio: ${order.tracking_code}\n`;
      }
      if (order.paid_at) {
        txtContent += `   Data do Pagamento: ${formatDate(order.paid_at)}\n`;
      }
      txtContent += '\n';

      txtContent += '👤 DADOS DO CLIENTE:\n';
      txtContent += `   Nome: ${order.customer.name}\n`;
      txtContent += `   CPF: ${order.customer.cpf}\n`;
      txtContent += `   Email: ${order.customer.email}\n`;
      txtContent += `   Telefone: ${order.customer.phone}\n`;
      txtContent += '\n';

      txtContent += '📦 PRODUTOS:\n';
      order.items.forEach((item, itemIndex) => {
        txtContent += `   ${itemIndex + 1}. ${item.product_name}\n`;
        txtContent += `      Quantidade: ${item.quantity}\n`;
        txtContent += `      Preço Unitário: R$ ${formatCurrency(item.unit_price)}\n`;
      });
      txtContent += '\n';

      txtContent += '📍 ENDEREÇO DE ENTREGA:\n';
      txtContent += `   ${order.shipping_address.address}, ${order.shipping_address.number}`;
      if (order.shipping_address.complement) {
        txtContent += ` - ${order.shipping_address.complement}`;
      }
      txtContent += '\n';
      txtContent += `   ${order.shipping_address.neighborhood}\n`;
      txtContent += `   ${order.shipping_address.city} - ${order.shipping_address.state}\n`;
      txtContent += `   CEP: ${order.shipping_address.cep}\n`;
      txtContent += '\n';

      txtContent += '💰 VALORES:\n';
      txtContent += `   Subtotal: R$ ${formatCurrency(order.subtotal)}\n`;
      txtContent += `   Frete: R$ ${formatCurrency(order.shipping_fee)}\n`;
      txtContent += `   TOTAL: R$ ${formatCurrency(order.amount)}\n`;
      txtContent += '\n\n';
    });

    txtContent += '═══════════════════════════════════════════════════════════════════════\n';
    txtContent += '                           FIM DO RELATÓRIO                              \n';
    txtContent += '═══════════════════════════════════════════════════════════════════════\n';

    const blob = new Blob([txtContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pedidos_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    alert(`${ordersToExport.length} pedido(s) exportado(s) com sucesso!`);
  };

  const updateOrderTracking = async () => {
    if (!selectedOrder || (!newTrackingCode.trim() && !newTrackingUrl.trim())) return;

    setIsSaving(true);

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/update-order`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          order_id: selectedOrder.id,
          tracking_code: newTrackingCode.trim() || null,
          tracking_url: newTrackingUrl.trim() || null
        })
      });

      if (!response.ok) {
        throw new Error('Erro ao atualizar informações de rastreio');
      }

      setSelectedOrder({
        ...selectedOrder,
        tracking_code: newTrackingCode.trim() || null,
        tracking_url: newTrackingUrl.trim() || null
      });
      setEditingTracking(false);
      await loadAllOrders();
    } catch (err) {
      console.error('Erro ao atualizar rastreio:', err);
      alert('Erro ao atualizar informações de rastreio');
    } finally {
      setIsSaving(false);
    }
  };

  const updateOrderStatus = async () => {
    if (!selectedOrder || !newStatus) return;

    setIsSaving(true);

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/update-order`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          order_id: selectedOrder.id,
          status: newStatus
        })
      });

      if (!response.ok) {
        throw new Error('Erro ao atualizar status');
      }

      setSelectedOrder({ ...selectedOrder, status: newStatus });
      setEditingStatus(false);
      await loadAllOrders();
    } catch (err) {
      console.error('Erro ao atualizar status:', err);
      alert('Erro ao atualizar status do pedido');
    } finally {
      setIsSaving(false);
    }
  };

  const getStatusInfo = (status: string) => {
    const statusMap: Record<string, { label: string; color: string; icon: any; bg: string }> = {
      pending: { label: 'Aguardando Pagamento', color: 'text-yellow-700', icon: Clock, bg: 'bg-yellow-50 border-yellow-200' },
      paid: { label: 'Aprovado', color: 'text-green-700', icon: CheckCircle, bg: 'bg-green-50 border-green-200' },
      processing: { label: 'Em Preparação', color: 'text-blue-700', icon: Package, bg: 'bg-blue-50 border-blue-200' },
      shipped: { label: 'Em Trânsito', color: 'text-purple-700', icon: Truck, bg: 'bg-purple-50 border-purple-200' },
      delivered: { label: 'Entregue', color: 'text-green-700', icon: CheckCircle, bg: 'bg-green-50 border-green-200' },
      cancelled: { label: 'Cancelado', color: 'text-red-700', icon: AlertCircle, bg: 'bg-red-50 border-red-200' }
    };
    return statusMap[status] || statusMap.pending;
  };

  const formatCurrency = (cents: number) => {
    return (cents / 100).toFixed(2).replace('.', ',');
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStats = () => {
    const totalRevenue = orders.filter(o => o.status !== 'cancelled').reduce((sum, o) => sum + o.amount, 0);
    const pendingOrders = orders.filter(o => o.status === 'pending').length;
    const shippedOrders = orders.filter(o => o.status === 'shipped' || o.status === 'delivered').length;

    return {
      totalOrders: orders.length,
      totalRevenue,
      pendingOrders,
      shippedOrders
    };
  };

  const stats = getStats();

  if (selectedOrder) {
    const statusInfo = getStatusInfo(selectedOrder.status);
    const StatusIcon = statusInfo.icon;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 overflow-y-auto">
        <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[95vh] overflow-y-auto shadow-2xl relative">
          <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-6 rounded-t-3xl z-10 shadow-lg">
            <button
              onClick={() => {
                setSelectedOrder(null);
                setEditingTracking(false);
                setEditingStatus(false);
              }}
              className="absolute top-4 right-4 text-white hover:text-gray-200 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full p-2 transition-colors"
            >
              <X size={24} />
            </button>
            <h2 className="text-2xl font-black mb-2">Gerenciar Pedido</h2>
            <p className="text-sm opacity-90">#{selectedOrder.transaction_id}</p>
          </div>

          <div className="p-6">
            <div className={`${statusInfo.bg} border-2 rounded-xl p-4 mb-6`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <StatusIcon size={32} className={statusInfo.color} />
                  <div>
                    <p className={`font-black text-lg ${statusInfo.color}`}>{statusInfo.label}</p>
                    <p className="text-sm text-gray-600">
                      Pedido realizado em {formatDate(selectedOrder.created_at)}
                    </p>
                  </div>
                </div>
                {!editingStatus ? (
                  <button
                    onClick={() => {
                      setEditingStatus(true);
                      setNewStatus(selectedOrder.status);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 transition-colors"
                  >
                    <Edit2 size={16} />
                    Alterar Status
                  </button>
                ) : (
                  <div className="flex items-center gap-2">
                    <select
                      value={newStatus}
                      onChange={(e) => {
                        setNewStatus(e.target.value);
                        if (e.target.value === 'shipped') {
                          setEditingTracking(true);
                        }
                      }}
                      className="px-3 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    >
                      <option value="pending">Aguardando Pagamento</option>
                      <option value="paid">Aprovado</option>
                      <option value="processing">Em Preparação</option>
                      <option value="shipped">Em Trânsito</option>
                      <option value="delivered">Entregue</option>
                      <option value="cancelled">Cancelado</option>
                    </select>
                    <button
                      onClick={updateOrderStatus}
                      disabled={isSaving}
                      className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 disabled:opacity-50"
                    >
                      <Save size={16} />
                      {isSaving ? 'Salvando...' : 'Salvar'}
                    </button>
                    <button
                      onClick={() => setEditingStatus(false)}
                      className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg font-bold text-sm"
                    >
                      Cancelar
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Truck size={20} className="text-blue-600" />
                  <p className="font-bold text-blue-900">Informações de Rastreio</p>
                </div>
                {!editingTracking && (
                  <button
                    onClick={() => {
                      setEditingTracking(true);
                      setNewTrackingCode(selectedOrder.tracking_code || '');
                      setNewTrackingUrl(selectedOrder.tracking_url || '');
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 transition-colors"
                  >
                    <Edit2 size={16} />
                    {selectedOrder.tracking_code || selectedOrder.tracking_url ? 'Editar' : 'Adicionar'}
                  </button>
                )}
              </div>
              {!editingTracking ? (
                <div className="space-y-3">
                  {selectedOrder.tracking_code ? (
                    <div>
                      <p className="text-xs text-blue-600 mb-1">Código de Rastreio:</p>
                      <p className="text-xl font-black text-blue-700">{selectedOrder.tracking_code}</p>
                    </div>
                  ) : null}
                  {selectedOrder.tracking_url ? (
                    <div>
                      <p className="text-xs text-blue-600 mb-1">Link da Transportadora:</p>
                      <a
                        href={selectedOrder.tracking_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 hover:text-blue-800 underline break-all"
                      >
                        {selectedOrder.tracking_url}
                      </a>
                    </div>
                  ) : null}
                  {!selectedOrder.tracking_code && !selectedOrder.tracking_url && (
                    <p className="text-gray-500 italic">Nenhuma informação de rastreio adicionada</p>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-blue-700 mb-1">
                      Código de Rastreio
                    </label>
                    <input
                      type="text"
                      value={newTrackingCode}
                      onChange={(e) => setNewTrackingCode(e.target.value)}
                      placeholder="Ex: AA123456789BR"
                      className="w-full px-4 py-2 border-2 border-blue-300 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-blue-700 mb-1">
                      Link da Transportadora
                    </label>
                    <input
                      type="url"
                      value={newTrackingUrl}
                      onChange={(e) => setNewTrackingUrl(e.target.value)}
                      placeholder="Ex: https://rastreamento.correios.com.br/..."
                      className="w-full px-4 py-2 border-2 border-blue-300 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={updateOrderTracking}
                      disabled={isSaving}
                      className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 disabled:opacity-50"
                    >
                      <Save size={16} />
                      {isSaving ? 'Salvando...' : 'Salvar'}
                    </button>
                    <button
                      onClick={() => setEditingTracking(false)}
                      className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg font-bold"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="font-black text-lg mb-4 flex items-center gap-2">
                  <Mail size={20} />
                  Dados do Cliente
                </h3>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">Nome:</p>
                  <p className="font-bold text-gray-900">{selectedOrder.customer.name}</p>
                  <p className="text-sm text-gray-600 mt-3">CPF:</p>
                  <p className="font-bold text-gray-900">{selectedOrder.customer.cpf}</p>
                  <p className="text-sm text-gray-600 mt-3">Email:</p>
                  <p className="font-bold text-gray-900">{selectedOrder.customer.email}</p>
                  <p className="text-sm text-gray-600 mt-3">Telefone:</p>
                  <p className="font-bold text-gray-900">{selectedOrder.customer.phone}</p>
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="font-black text-lg mb-4 flex items-center gap-2">
                  <MapPin size={20} />
                  Endereço de Entrega
                </h3>
                <div className="bg-white p-4 rounded-lg">
                  <p className="text-gray-900 font-medium">
                    {selectedOrder.shipping_address.address}, {selectedOrder.shipping_address.number}
                    {selectedOrder.shipping_address.complement && ` - ${selectedOrder.shipping_address.complement}`}
                  </p>
                  <p className="text-gray-900 font-medium">
                    {selectedOrder.shipping_address.neighborhood}
                  </p>
                  <p className="text-gray-900 font-medium">
                    {selectedOrder.shipping_address.city} - {selectedOrder.shipping_address.state}
                  </p>
                  <p className="text-gray-600 text-sm mt-1">
                    CEP: {selectedOrder.shipping_address.cep}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-6 mb-6">
              <h3 className="font-black text-lg mb-4 flex items-center gap-2">
                <Package size={20} />
                Produtos
              </h3>
              <div className="space-y-3">
                {selectedOrder.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center bg-white p-3 rounded-lg">
                    <div>
                      <p className="font-bold text-gray-900">{item.product_name}</p>
                      <p className="text-sm text-gray-600">Quantidade: {item.quantity}</p>
                    </div>
                    <p className="font-bold text-gray-900">R$ {formatCurrency(item.unit_price)}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-400 rounded-xl p-6">
              <h3 className="font-black text-lg mb-4 flex items-center gap-2">
                <DollarSign size={20} />
                Resumo Financeiro
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between text-gray-800">
                  <span className="font-medium">Subtotal:</span>
                  <span className="font-bold">R$ {formatCurrency(selectedOrder.subtotal)}</span>
                </div>
                <div className="flex justify-between text-gray-800">
                  <span className="font-medium">Frete:</span>
                  <span className="font-bold">R$ {formatCurrency(selectedOrder.shipping_fee)}</span>
                </div>
                <div className="border-t-2 border-green-500 pt-2 mt-2">
                  <div className="flex justify-between">
                    <span className="font-black text-xl text-gray-900">TOTAL:</span>
                    <span className="font-black text-2xl text-green-600">
                      R$ {formatCurrency(selectedOrder.amount)}
                    </span>
                  </div>
                </div>
                {selectedOrder.paid_at && (
                  <p className="text-sm text-green-700 font-medium mt-2">
                    ✓ Pagamento confirmado em {formatDate(selectedOrder.paid_at)}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-7xl w-full max-h-[95vh] overflow-y-auto shadow-2xl relative">
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-6 rounded-t-3xl z-10 shadow-lg">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white hover:text-gray-200 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full p-2 transition-colors"
          >
            <X size={24} />
          </button>
          <h2 className="text-3xl font-black mb-2">Painel Administrativo</h2>
          <p className="text-sm opacity-90">Gerencie todos os pedidos da loja</p>
          <button
            onClick={onLogout}
            className="mt-4 text-sm bg-white bg-opacity-20 hover:bg-opacity-30 px-4 py-2 rounded-full transition-all font-semibold"
          >
            Sair da Conta
          </button>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
              <div className="flex items-center justify-between mb-2">
                <ShoppingBag size={32} />
                <TrendingUp size={24} className="opacity-70" />
              </div>
              <p className="text-3xl font-black mb-1">{stats.totalOrders}</p>
              <p className="text-sm opacity-90">Total de Pedidos</p>
            </div>

            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white shadow-lg">
              <div className="flex items-center justify-between mb-2">
                <DollarSign size={32} />
                <TrendingUp size={24} className="opacity-70" />
              </div>
              <p className="text-3xl font-black mb-1">R$ {formatCurrency(stats.totalRevenue)}</p>
              <p className="text-sm opacity-90">Receita Total</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-xl p-6 text-white shadow-lg">
              <div className="flex items-center justify-between mb-2">
                <Clock size={32} />
                <AlertCircle size={24} className="opacity-70" />
              </div>
              <p className="text-3xl font-black mb-1">{stats.pendingOrders}</p>
              <p className="text-sm opacity-90">Aguardando Pagamento</p>
            </div>

            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white shadow-lg">
              <div className="flex items-center justify-between mb-2">
                <Truck size={32} />
                <CheckCircle size={24} className="opacity-70" />
              </div>
              <p className="text-3xl font-black mb-1">{stats.shippedOrders}</p>
              <p className="text-sm opacity-90">Enviados/Entregues</p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-xl p-6 mb-6">
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Buscar por pedido, cliente, email ou CPF..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none font-medium"
              >
                <option value="all">Todos os Status</option>
                <option value="pending">Aguardando Pagamento</option>
                <option value="paid">Aprovado</option>
                <option value="processing">Em Preparação</option>
                <option value="shipped">Em Trânsito</option>
                <option value="delivered">Entregue</option>
                <option value="cancelled">Cancelado</option>
              </select>
            </div>

            {filteredOrders.length > 0 && (
              <div className="flex items-center justify-between pt-4 border-t-2 border-gray-200">
                <div className="flex items-center gap-4">
                  <button
                    onClick={toggleSelectAll}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg font-bold transition-colors"
                  >
                    {selectAll ? <CheckSquare size={20} /> : <Square size={20} />}
                    {selectAll ? 'Desmarcar Todos' : 'Selecionar Todos'}
                  </button>
                  <span className="text-sm text-gray-600">
                    {selectedOrderIds.size} de {filteredOrders.length} selecionados
                  </span>
                </div>
                <button
                  onClick={exportSelectedOrders}
                  disabled={selectedOrderIds.size === 0}
                  className="flex items-center gap-2 px-6 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white rounded-lg font-bold transition-colors"
                >
                  <Download size={20} />
                  Exportar Selecionados
                </button>
              </div>
            )}
          </div>

          {isLoading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              <p className="mt-4 text-gray-600 font-medium">Carregando pedidos...</p>
            </div>
          ) : error ? (
            <div className="bg-red-50 border-2 border-red-200 rounded-xl p-6 text-center">
              <AlertCircle size={48} className="mx-auto text-red-600 mb-4" />
              <p className="text-red-700 font-medium">{error}</p>
            </div>
          ) : filteredOrders.length === 0 ? (
            <div className="bg-gray-50 border-2 border-gray-200 rounded-xl p-12 text-center">
              <Package size={64} className="mx-auto text-gray-400 mb-4" />
              <p className="text-gray-700 font-bold text-lg mb-2">Nenhum pedido encontrado</p>
              <p className="text-gray-600">Tente ajustar os filtros de busca</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredOrders.map((order) => {
                const statusInfo = getStatusInfo(order.status);
                const StatusIcon = statusInfo.icon;

                const isSelected = selectedOrderIds.has(order.id);

                return (
                  <div
                    key={order.id}
                    className={`bg-white border-2 ${isSelected ? 'border-blue-500 bg-blue-50' : 'border-gray-200'} hover:border-blue-500 rounded-xl p-5 transition-all hover:shadow-lg`}
                  >
                    <div className="flex items-start gap-4">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleOrderSelection(order.id);
                        }}
                        className="mt-1 flex-shrink-0"
                      >
                        {isSelected ? (
                          <CheckSquare size={24} className="text-blue-600" />
                        ) : (
                          <Square size={24} className="text-gray-400 hover:text-blue-600" />
                        )}
                      </button>

                      <div
                        onClick={() => setSelectedOrder(order)}
                        className="flex-1 cursor-pointer"
                      >
                        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <StatusIcon size={18} className={statusInfo.color} />
                              <span className={`font-bold text-sm ${statusInfo.color}`}>{statusInfo.label}</span>
                            </div>
                            <p className="font-bold text-gray-900 mb-1">
                              #{order.transaction_id}
                            </p>
                            <p className="text-sm text-gray-700">
                              <strong>Cliente:</strong> {order.customer.name}
                            </p>
                            <p className="text-xs text-gray-600 mt-1">
                              {formatDate(order.created_at)}
                            </p>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-center">
                              <p className="text-sm text-gray-600 mb-1">Itens</p>
                              <p className="font-bold text-gray-900">{order.items.length}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-sm text-gray-600 mb-1">Valor Total</p>
                              <p className="font-black text-xl text-green-600">
                                R$ {formatCurrency(order.amount)}
                              </p>
                            </div>
                            <div className="text-center">
                              <p className="text-sm text-gray-600 mb-1">Rastreio</p>
                              <p className="font-bold text-gray-900">
                                {order.tracking_code ? '✓' : '-'}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
