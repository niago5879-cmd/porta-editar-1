import { Copy, CheckCircle, Clock, QrCode } from 'lucide-react';
import { useState, useEffect } from 'react';

interface PixPaymentProps {
  pixData: {
    qrcode: string;
    expirationDate: string;
    amount: number;
    transactionId: number;
  };
  customer: {
    name: string;
    email: string;
  };
  products: string[];
  onClose: () => void;
}

export default function PixPayment({ pixData, customer, products, onClose }: PixPaymentProps) {
  const [copied, setCopied] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState<number>(0);

  useEffect(() => {
    const expirationTime = new Date(pixData.expirationDate).getTime();
    const now = new Date().getTime();
    const diff = Math.floor((expirationTime - now) / 1000);
    setTimeRemaining(diff > 0 ? diff : 0);

    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [pixData.expirationDate]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(pixData.qrcode);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch (err) {
      console.error('Erro ao copiar:', err);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl animate-slide-up max-h-[90vh] overflow-y-auto">
        <div className="p-6 md:p-8">
          <div className="text-center mb-6">
            <div className="flex items-center justify-center mb-4">
              <div className="bg-green-100 p-4 rounded-full">
                <QrCode className="text-green-600" size={48} />
              </div>
            </div>
            <h2 className="text-3xl font-black text-gray-900 mb-2">
              Pagamento via PIX
            </h2>
            <p className="text-gray-600">
              Escaneie o QR Code ou copie o código para finalizar o pagamento
            </p>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-6 mb-6 border-2 border-green-200">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Clock className="text-orange-600" size={20} />
              <span className="text-sm font-bold text-gray-700">
                Tempo restante: <span className="text-orange-600">{formatTime(timeRemaining)}</span>
              </span>
            </div>

            <div className="bg-white p-4 rounded-xl mb-4 flex items-center justify-center">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(pixData.qrcode)}`}
                alt="QR Code PIX"
                className="w-64 h-64"
              />
            </div>

            <div className="space-y-3">
              <div className="bg-white rounded-xl p-4 border-2 border-gray-200">
                <p className="text-xs font-bold text-gray-600 mb-2">CÓDIGO PIX COPIA E COLA:</p>
                <p className="text-xs text-gray-800 break-all font-mono mb-3">
                  {pixData.qrcode}
                </p>
                <button
                  onClick={handleCopy}
                  className={`w-full py-3 rounded-xl font-bold text-white transition-all transform hover:scale-105 flex items-center justify-center gap-2 ${
                    copied
                      ? 'bg-green-600 hover:bg-green-700'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {copied ? (
                    <>
                      <CheckCircle size={20} />
                      CÓDIGO COPIADO!
                    </>
                  ) : (
                    <>
                      <Copy size={20} />
                      COPIAR CÓDIGO PIX
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-2xl p-6 mb-6">
            <h3 className="text-lg font-black text-gray-900 mb-4">Detalhes do Pedido</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Cliente:</span>
                <span className="font-bold text-gray-900">{customer.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">E-mail:</span>
                <span className="font-bold text-gray-900 text-sm">{customer.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">ID da Transação:</span>
                <span className="font-bold text-gray-900">#{pixData.transactionId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Produtos:</span>
                <span className="font-bold text-gray-900">{products.length} item(ns)</span>
              </div>
              <div className="border-t-2 border-gray-200 pt-3 mt-3">
                <div className="flex justify-between items-center">
                  <span className="text-xl font-black text-gray-900">TOTAL:</span>
                  <span className="text-2xl font-black text-green-600">
                    R$ {(pixData.amount / 100).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 rounded-xl p-4 mb-6 border border-blue-200">
            <h4 className="font-bold text-blue-900 mb-2 flex items-center gap-2">
              <CheckCircle size={18} />
              Como pagar com PIX:
            </h4>
            <ol className="text-sm text-blue-800 space-y-1 ml-6 list-decimal">
              <li>Abra o app do seu banco</li>
              <li>Escolha a opção Pagar com PIX</li>
              <li>Escaneie o QR Code ou cole o código</li>
              <li>Confirme o pagamento</li>
              <li>Pronto! Você receberá a confirmação por e-mail</li>
            </ol>
          </div>

          <button
            onClick={onClose}
            className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-4 rounded-xl transition-colors"
          >
            FECHAR
          </button>
        </div>
      </div>
    </div>
  );
}
