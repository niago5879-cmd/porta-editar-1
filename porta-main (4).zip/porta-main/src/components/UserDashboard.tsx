import { X, Package, Truck, CheckCircle, Clock, AlertCircle, MapPin, User, Mail, Phone, Calendar, CreditCard, Copy } from 'lucide-react';
import { useState, useEffect } from 'react';

interface Order {
  id: string;
  transaction_id: string;
  status: string;
  amount: number;
  subtotal: number;
  shipping_fee: number;
  tracking_code: string | null;
  tracking_url: string | null;
  pix_qrcode: string | null;
  pix_qrcode_text: string | null;
  pix_expiration: string | null;
  created_at: string;
  paid_at: string | null;
  items: Array<{
    product_name: string;
    quantity: number;
    unit_price: number;
  }>;
  shipping_address: {
    address: string;
    number: string;
    complement: string | null;
    neighborhood: string;
    city: string;
    state: string;
    cep: string;
  };
  customer: {
    name: string;
    email: string;
    phone: string;
  };
}

interface UserDashboardProps {
  onClose: () => void;
  cpf: string;
  onLogout: () => void;
}

export default function UserDashboard({ onClose, cpf, onLogout }: UserDashboardProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    loadOrders();
  }, [cpf]);

  const loadOrders = async () => {
    setIsLoading(true);
    setError('');

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/get-customer-orders`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ cpf })
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Erro ao carregar pedidos');
        setIsLoading(false);
        return;
      }

      setOrders(data.orders || []);
    } catch (err) {
      console.error('Erro ao carregar pedidos:', err);
      setError('Erro ao carregar pedidos. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusInfo = (status: string) => {
    const statusMap: Record<string, { label: string; color: string; icon: any; bg: string }> = {
      pending: { label: 'Aguardando Pagamento', color: 'text-yellow-700', icon: Clock, bg: 'bg-yellow-50 border-yellow-200' },
      paid: { label: 'Aprovado', color: 'text-green-700', icon: CheckCircle, bg: 'bg-green-50 border-green-200' },
      processing: { label: 'Em Preparação', color: 'text-blue-700', icon: Package, bg: 'bg-blue-50 border-blue-200' },
      shipped: { label: 'Em Trânsito', color: 'text-purple-700', icon: Truck, bg: 'bg-purple-50 border-purple-200' },
      delivered: { label: 'Entregue', color: 'text-green-700', icon: CheckCircle, bg: 'bg-green-50 border-green-200' },
      cancelled: { label: 'Cancelado', color: 'text-red-700', icon: AlertCircle, bg: 'bg-red-50 border-red-200' }
    };
    return statusMap[status] || statusMap.pending;
  };

  const formatCurrency = (cents: number) => {
    return (cents / 100).toFixed(2).replace('.', ',');
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (selectedOrder) {
    const statusInfo = getStatusInfo(selectedOrder.status);
    const StatusIcon = statusInfo.icon;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 overflow-y-auto">
        <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[95vh] overflow-y-auto shadow-2xl relative">
          <div className="sticky top-0 bg-gradient-to-r from-green-600 to-green-700 text-white p-6 rounded-t-3xl z-10 shadow-lg">
            <button
              onClick={() => setSelectedOrder(null)}
              className="absolute top-4 right-4 text-white hover:text-gray-200 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full p-2 transition-colors"
            >
              <X size={24} />
            </button>
            <h2 className="text-2xl font-black mb-2">Detalhes do Pedido</h2>
            <p className="text-sm opacity-90">Pedido #{selectedOrder.transaction_id}</p>
          </div>

          <div className="p-6">
            <div className={`${statusInfo.bg} border-2 rounded-xl p-4 mb-6`}>
              <div className="flex items-center gap-3">
                <StatusIcon size={32} className={statusInfo.color} />
                <div>
                  <p className={`font-black text-lg ${statusInfo.color}`}>{statusInfo.label}</p>
                  <p className="text-sm text-gray-600">
                    Pedido realizado em {formatDate(selectedOrder.created_at)}
                  </p>
                </div>
              </div>
            </div>

            {selectedOrder.status === 'pending' && selectedOrder.pix_qrcode && (
              <div className="bg-yellow-50 border-2 border-yellow-400 rounded-xl p-6 mb-6">
                <div className="text-center">
                  <h3 className="font-black text-xl text-yellow-900 mb-4">
                    👆 Escaneie o QR Code para Pagar
                  </h3>
                  <div className="bg-white p-4 rounded-xl inline-block mb-4">
                    <img
                      src={selectedOrder.pix_qrcode}
                      alt="QR Code PIX"
                      className="w-64 h-64 mx-auto"
                      onError={(e) => {
                        console.error('Erro ao carregar QR Code');
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                  </div>
                  <p className="text-sm text-yellow-800 font-medium mb-4">
                    Abra o app do seu banco e escaneie o QR Code
                  </p>

                  {selectedOrder.pix_qrcode_text && (
                    <div className="mt-4">
                      <p className="text-sm font-bold text-yellow-900 mb-2">
                        Ou copie o código PIX:
                      </p>
                      <div className="bg-white border-2 border-yellow-300 rounded-lg p-3 flex items-center gap-2">
                        <input
                          type="text"
                          value={selectedOrder.pix_qrcode_text}
                          readOnly
                          className="flex-1 bg-transparent text-xs text-gray-800 outline-none"
                        />
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(selectedOrder.pix_qrcode_text!);
                            alert('Código PIX copiado!');
                          }}
                          className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 transition-colors"
                        >
                          <Copy size={16} />
                          Copiar
                        </button>
                      </div>
                    </div>
                  )}

                  {selectedOrder.pix_expiration && (
                    <p className="text-xs text-yellow-700 mt-4">
                      QR Code válido até: {formatDate(selectedOrder.pix_expiration)}
                    </p>
                  )}
                </div>
              </div>
            )}

            {(selectedOrder.tracking_code || selectedOrder.tracking_url) && (
              <div className="bg-purple-50 border-2 border-purple-200 rounded-xl p-4 mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <Truck size={20} className="text-purple-600" />
                  <p className="font-bold text-purple-900">Informações de Rastreio</p>
                </div>

                {selectedOrder.tracking_code && (
                  <div className="mb-3">
                    <p className="text-xs text-purple-600 mb-1">Código de Rastreio:</p>
                    <p className="text-2xl font-black text-purple-700">{selectedOrder.tracking_code}</p>
                  </div>
                )}

                {selectedOrder.tracking_url && (
                  <div className="mb-3">
                    <p className="text-xs text-purple-600 mb-2">Rastrear Pedido:</p>
                    <a
                      href={selectedOrder.tracking_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-bold text-sm transition-colors"
                    >
                      Acessar Rastreamento da Transportadora →
                    </a>
                  </div>
                )}

                {selectedOrder.tracking_code && !selectedOrder.tracking_url && (
                  <a
                    href={`https://rastreamento.correios.com.br/app/index.php?objeto=${selectedOrder.tracking_code}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-bold text-sm transition-colors"
                  >
                    Rastrear no site dos Correios →
                  </a>
                )}
              </div>
            )}

            <div className="bg-gray-50 rounded-xl p-6 mb-6">
              <h3 className="font-black text-lg mb-4 flex items-center gap-2">
                <Package size={20} />
                Produtos
              </h3>
              <div className="space-y-3">
                {selectedOrder.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center bg-white p-3 rounded-lg">
                    <div>
                      <p className="font-bold text-gray-900">{item.product_name}</p>
                      <p className="text-sm text-gray-600">Quantidade: {item.quantity}</p>
                    </div>
                    <p className="font-bold text-gray-900">R$ {formatCurrency(item.unit_price)}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-6 mb-6">
              <h3 className="font-black text-lg mb-4 flex items-center gap-2">
                <MapPin size={20} />
                Endereço de Entrega
              </h3>
              <div className="bg-white p-4 rounded-lg">
                <p className="text-gray-900 font-medium">
                  {selectedOrder.shipping_address.address}, {selectedOrder.shipping_address.number}
                  {selectedOrder.shipping_address.complement && ` - ${selectedOrder.shipping_address.complement}`}
                </p>
                <p className="text-gray-900 font-medium">
                  {selectedOrder.shipping_address.neighborhood}
                </p>
                <p className="text-gray-900 font-medium">
                  {selectedOrder.shipping_address.city} - {selectedOrder.shipping_address.state}
                </p>
                <p className="text-gray-600 text-sm mt-1">
                  CEP: {selectedOrder.shipping_address.cep}
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-orange-50 border-2 border-yellow-400 rounded-xl p-6">
              <h3 className="font-black text-lg mb-4 flex items-center gap-2">
                <CreditCard size={20} />
                Resumo do Pagamento
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between text-gray-800">
                  <span className="font-medium">Subtotal:</span>
                  <span className="font-bold">R$ {formatCurrency(selectedOrder.subtotal)}</span>
                </div>
                <div className="flex justify-between text-gray-800">
                  <span className="font-medium">Frete:</span>
                  <span className="font-bold">R$ {formatCurrency(selectedOrder.shipping_fee)}</span>
                </div>
                <div className="border-t-2 border-yellow-500 pt-2 mt-2">
                  <div className="flex justify-between">
                    <span className="font-black text-xl text-gray-900">TOTAL:</span>
                    <span className="font-black text-2xl text-green-600">
                      R$ {formatCurrency(selectedOrder.amount)}
                    </span>
                  </div>
                </div>
                {selectedOrder.paid_at && (
                  <p className="text-sm text-green-700 font-medium mt-2">
                    ✓ Pagamento confirmado em {formatDate(selectedOrder.paid_at)}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[95vh] overflow-y-auto shadow-2xl relative">
        <div className="sticky top-0 bg-gradient-to-r from-green-600 to-green-700 text-white p-6 rounded-t-3xl z-10 shadow-lg">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white hover:text-gray-200 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full p-2 transition-colors"
          >
            <X size={24} />
          </button>
          <h2 className="text-3xl font-black mb-2">Meus Pedidos</h2>
          <p className="text-sm opacity-90">Acompanhe todos os seus pedidos</p>
          <button
            onClick={onLogout}
            className="mt-4 text-sm bg-white bg-opacity-20 hover:bg-opacity-30 px-4 py-2 rounded-full transition-all font-semibold"
          >
            Sair da Conta
          </button>
        </div>

        <div className="p-6">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
              <p className="mt-4 text-gray-600 font-medium">Carregando pedidos...</p>
            </div>
          ) : error ? (
            <div className="bg-red-50 border-2 border-red-200 rounded-xl p-6 text-center">
              <AlertCircle size={48} className="mx-auto text-red-600 mb-4" />
              <p className="text-red-700 font-medium">{error}</p>
            </div>
          ) : orders.length === 0 ? (
            <div className="bg-gray-50 border-2 border-gray-200 rounded-xl p-12 text-center">
              <Package size={64} className="mx-auto text-gray-400 mb-4" />
              <p className="text-gray-700 font-bold text-lg mb-2">Nenhum pedido encontrado</p>
              <p className="text-gray-600">Você ainda não fez nenhum pedido.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => {
                const statusInfo = getStatusInfo(order.status);
                const StatusIcon = statusInfo.icon;

                return (
                  <div
                    key={order.id}
                    onClick={() => setSelectedOrder(order)}
                    className="bg-white border-2 border-gray-200 hover:border-green-500 rounded-xl p-6 cursor-pointer transition-all hover:shadow-lg"
                  >
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <StatusIcon size={20} className={statusInfo.color} />
                          <span className={`font-bold ${statusInfo.color}`}>{statusInfo.label}</span>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">
                          Pedido #{order.transaction_id}
                        </p>
                        <p className="text-sm text-gray-600">
                          {formatDate(order.created_at)}
                        </p>
                        <p className="text-sm text-gray-700 mt-2 font-medium">
                          {order.items.length} {order.items.length === 1 ? 'item' : 'itens'}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-black text-2xl text-green-600">
                          R$ {formatCurrency(order.amount)}
                        </p>
                        <p className="text-sm text-gray-600 mt-1">
                          Clique para ver detalhes →
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
