import { ShoppingCart, Shield, Truck, Star, Lock, CheckCircle, Award, X, Ruler, Sparkles, Zap, Scissors, ShieldCheck, User } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import PixPayment from './components/PixPayment';
import LoginModal from './components/LoginModal';
import UserDashboard from './components/UserDashboard';
import AdminDashboard from './components/AdminDashboard';

interface Product {
  id: string;
  name: string;
  image: string;
  description: string;
}

function App() {
  const products: Product[] = [
    {
      id: 'natal-quebra-nozes',
      name: 'Natal Quebra Nozes',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mgc7rgqpdvyc9a.webp',
      description: 'Tradição e elegância natalina'
    },
    {
      id: 'guirlanda',
      name: 'Feliz Natal',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mgc7rgqpfais08.webp',
      description: 'Beleza e acolhimento na porta'
    },
    {
      id: 'biscoito-feliz-natal',
      name: 'Biscoito Feliz Natal',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mgc7rgqpchdw70.webp',
      description: 'Doçura e alegria do Natal'
    },
    {
      id: 'natal-abencoado',
      name: 'Natal Abençoado',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mgc7rgqpmbd055.webp',
      description: 'Bênçãos para toda família'
    },
    {
      id: 'religioso',
      name: 'Religioso',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mgc7rgqpji84eb.webp',
      description: 'Fé e devoção natalina'
    },
    {
      id: 'luz-de-jesus',
      name: 'Luz de Jesus',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mgc7rgqpgp383d.webp',
      description: 'A luz que ilumina os corações'
    },
    {
      id: 'nossa-senhorinha',
      name: 'Nossa Senhorinha',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mgc7rgqpi3nof8.webp',
      description: 'Proteção e amor maternal'
    },
    {
      id: 'feliz-natal-papai-noel',
      name: 'Feliz Natal Papai Noel',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mggsvbw8s5q861.webp',
      description: 'Alegria e diversão natalina'
    },
    {
      id: 'presentes-do-noel',
      name: 'Presentes do Noel',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mggsvbw8wdfkb4.webp',
      description: 'Generosidade e presentes'
    },
    {
      id: 'noel-presentes',
      name: 'Noel Presentes',
      image: 'https://down-br.img.susercontent.com/file/br-11134207-81z1k-mgdphnu52rd133.webp',
      description: 'Alegria e presentes do bom velhinho'
    }
  ];

  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [showCheckoutForm, setShowCheckoutForm] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(600);
  const [isMuted, setIsMuted] = useState(true);
  const [showPixPayment, setShowPixPayment] = useState(false);
  const [pixData, setPixData] = useState<any>(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showUserDashboard, setShowUserDashboard] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userCpf, setUserCpf] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);

  const ADMIN_CPF = '35928564805';
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    cpf: '',
    cep: '',
    address: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: ''
  });
  const modelsRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (showCheckoutForm && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [showCheckoutForm, timeRemaining]);

  const scrollToModels = () => {
    modelsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setIsMuted(videoRef.current.muted);
    }
  };

  const handleProductToggle = (productId: string) => {
    setSelectedProducts(prev => {
      if (prev.includes(productId)) {
        return prev.filter(id => id !== productId);
      } else {
        return [...prev, productId];
      }
    });
  };

  const handleBuyNow = () => {
    if (selectedProducts.length > 0) {
      setShowCheckoutForm(true);
      setTimeRemaining(600);
    }
  };

  const handleCepBlur = async () => {
    const cep = formData.cep.replace(/\D/g, '');
    if (cep.length === 8) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
        const data = await response.json();
        if (!data.erro) {
          setFormData(prev => ({
            ...prev,
            address: data.logradouro,
            neighborhood: data.bairro,
            city: data.localidade,
            state: data.uf
          }));
        }
      } catch (error) {
        console.error('Erro ao buscar CEP:', error);
      }
    }
  };


  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleFinalSubmit();
  };

  const handleFinalSubmit = async () => {
    setIsProcessingPayment(true);

    try {
      const totalProducts = selectedProducts.length;
      const subtotal = totalProducts * 24.90;
      const frete = 9.90;
      const total = subtotal + frete;
      const totalInCents = Math.round(total * 100);

      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/create-pix-payment`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: totalInCents,
          customer: {
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            cpf: formData.cpf,
            address: formData.address,
            number: formData.number,
            complement: formData.complement,
            cep: formData.cep,
            neighborhood: formData.neighborhood,
            city: formData.city,
            state: formData.state
          },
          items: selectedProducts.map(id => {
            const product = products.find(p => p.id === id);
            return {
              id: id,
              name: product?.name || 'Produto'
            };
          })
        })
      });

      const data = await response.json();

      console.log('Resposta completa:', data);

      if (!response.ok) {
        console.error('Erro na resposta:', data);
        throw new Error(data.error || data.details || 'Erro ao gerar pagamento PIX');
      }

      setPixData({
        qrcode: data.pix.qrcode,
        expirationDate: data.pix.expirationDate,
        amount: totalInCents,
        transactionId: data.id
      });

      setShowCheckoutForm(false);
      setShowPixPayment(true);
    } catch (error) {
      console.error('Erro ao processar pagamento:', error);
      alert('Erro ao processar pagamento. Por favor, tente novamente.');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header Natalino */}
      <header className="bg-gradient-to-r from-red-600 via-green-600 to-red-600 py-3 text-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex-1"></div>
            <p className="text-sm md:text-base font-bold text-center flex-1">
              🎄 FRETE FIXO DE R$9,90 | Entrega para todo Brasil 📦
            </p>
            <div className="flex-1 flex justify-end">
              <button
                onClick={() => setShowLoginModal(true)}
                className="flex items-center gap-2 bg-white bg-opacity-20 hover:bg-opacity-30 transition-all px-4 py-2 rounded-full group"
                title="Acessar minha conta"
              >
                <User size={20} className="group-hover:scale-110 transition-transform" />
                <span className="hidden md:inline text-sm font-semibold">Minha Conta</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-red-50 to-white py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-black text-center text-gray-900 mb-4">
            🎅 PORTA FELIZ
          </h1>
          <h2 className="text-2xl md:text-3xl font-bold text-center text-red-600 mb-4">
            Transforme Sua Porta em Magia de Natal!
          </h2>
          <p className="text-lg md:text-xl text-gray-700 mb-8 max-w-2xl mx-auto text-center">
            Surpreenda sua família e vizinhos com as capas decorativas mais lindas e fáceis de instalar!
          </p>

          {/* Vídeo Principal do Produto */}
          <div className="max-w-md mx-auto mb-8">
            <div className="bg-white rounded-2xl shadow-2xl p-6 transform hover:scale-105 transition-transform duration-300">
              <div className="aspect-[3/4] rounded-xl overflow-hidden relative group">
                <video
                  ref={videoRef}
                  src="https://down-ws-br.vod.susercontent.com/api/v4/11110105/mms/br-11110105-6kfkq-m1r1klxe5a144c.16000081729774604.mp4"
                  className="w-full h-full object-cover"
                  autoPlay
                  loop
                  muted
                  playsInline
                  onClick={toggleMute}
                >
                  Seu navegador não suporta vídeos.
                </video>
                <button
                  onClick={toggleMute}
                  className="absolute bottom-4 right-4 bg-black bg-opacity-60 hover:bg-opacity-80 text-white p-3 rounded-full transition-all shadow-lg"
                >
                  {isMuted ? (
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Preço Destaque */}
          <div className="bg-gradient-to-br from-yellow-300 via-yellow-400 to-yellow-500 rounded-3xl p-6 md:p-8 max-w-lg mx-auto mb-8 shadow-2xl border-4 border-yellow-600 transform hover:scale-105 transition-transform relative overflow-hidden text-center">
            <div className="absolute top-0 right-0 bg-red-600 text-white px-6 py-2 rotate-45 transform translate-x-8 -translate-y-2">
              <span className="font-bold text-sm">OFERTA</span>
            </div>
            <p className="text-gray-800 font-bold mb-1 text-sm md:text-base">DE:</p>
            <p className="text-gray-700 line-through text-2xl md:text-3xl mb-3 font-bold">R$ 79,90</p>
            <p className="text-green-800 font-black text-lg md:text-xl mb-2 animate-pulse">POR APENAS:</p>
            <p className="text-red-700 font-black text-5xl md:text-7xl mb-4 drop-shadow-lg">
              R$ 24<sup className="text-3xl md:text-4xl">,90</sup>
            </p>
            <div className="inline-block">
              <div className="bg-red-600 text-white px-6 py-3 rounded-full shadow-xl pulse-animation">
                <span className="font-black text-sm md:text-base">💥 ECONOMIZE 68% 💥</span>
              </div>
            </div>
          </div>

          {/* CTA Principal */}
          <button
            onClick={scrollToModels}
            className="cta-button w-full max-w-md mx-auto block mb-4"
          >
            <ShoppingCart className="inline-block mr-2" size={24} />
            COMPRAR AGORA
          </button>

          <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-700 mb-8 max-w-2xl mx-auto">
            <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-md">
              <Lock size={16} className="text-green-600" />
              <span className="font-semibold">Pagamento Seguro</span>
            </div>
            <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-md">
              <CheckCircle size={16} className="text-green-600" />
              <span className="font-semibold">Entrega Garantida</span>
            </div>
            <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-md">
              <Award size={16} className="text-green-600" />
              <span className="font-semibold">Loja Verificada</span>
            </div>
          </div>
        </div>
      </section>

      {/* Escolha o Modelo */}
      <section ref={modelsRef} className="py-12 bg-white scroll-mt-20">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl md:text-4xl font-black text-center text-gray-900 mb-4">
            🎄 Escolha Seus Modelos Favoritos
          </h3>
          <p className="text-center text-gray-600 mb-4">Todos os modelos por R$ 24,90 cada</p>
          <p className="text-center text-green-600 font-bold mb-10">
            ✨ Selecione quantos quiser! Quanto mais, melhor ✨
          </p>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 max-w-7xl mx-auto mb-10">
            {products.map((product) => (
              <div
                key={product.id}
                onClick={() => handleProductToggle(product.id)}
                className={`model-card cursor-pointer transition-all ${
                  selectedProducts.includes(product.id)
                    ? 'ring-4 ring-green-500 shadow-2xl scale-105'
                    : 'hover:ring-2 hover:ring-green-300'
                }`}
              >
                <div className="aspect-[3/4] rounded-xl overflow-hidden mb-3 relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  {selectedProducts.includes(product.id) && (
                    <div className="absolute top-2 right-2 bg-green-500 text-white rounded-full p-2 shadow-lg">
                      <CheckCircle size={20} />
                    </div>
                  )}
                  {selectedProducts.includes(product.id) && (
                    <div className="absolute inset-0 bg-green-500 bg-opacity-20 border-2 border-green-500 rounded-xl"></div>
                  )}
                </div>
                <h4 className="font-bold text-center text-sm md:text-base">{product.name}</h4>
                <p className="text-center text-xs text-gray-600 mt-1">{product.description}</p>
              </div>
            ))}
          </div>

          {selectedProducts.length > 0 && (
            <div className="bg-green-50 border-2 border-green-500 rounded-2xl p-6 max-w-2xl mx-auto mb-6">
              <div className="text-center">
                <p className="text-green-800 font-black text-xl mb-2">
                  🎉 {selectedProducts.length} {selectedProducts.length === 1 ? 'Produto Selecionado' : 'Produtos Selecionados'}
                </p>
                <p className="text-green-700 text-lg">
                  Subtotal: R$ {(selectedProducts.length * 24.90).toFixed(2)}
                </p>
                <p className="text-green-900 font-black text-2xl mt-2">
                  Total: R$ {(selectedProducts.length * 24.90 + 9.90).toFixed(2)}
                </p>
              </div>
            </div>
          )}

          {selectedProducts.length === 0 && (
            <p className="text-center text-red-600 font-bold mb-4 animate-pulse">
              ⬆️ Selecione pelo menos um modelo acima para continuar
            </p>
          )}

          <div className="text-center">
            <button
              onClick={handleBuyNow}
              disabled={selectedProducts.length === 0}
              className={`cta-button max-w-md mx-auto ${
                selectedProducts.length === 0 ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              <ShoppingCart className="inline-block mr-2" size={24} />
              COMPRAR AGORA ({selectedProducts.length})
            </button>
          </div>
        </div>
      </section>

      {/* Contador de Urgência */}
      <section className="py-6 bg-gradient-to-r from-red-600 via-red-700 to-red-600">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex flex-col md:flex-row items-center justify-center gap-4">
              <div className="bg-white rounded-lg px-6 py-3 shadow-xl">
                <p className="text-red-600 font-black text-2xl">⚡ 16 UNIDADES</p>
                <p className="text-gray-700 text-sm font-bold">RESTANTES HOJE</p>
              </div>
              <div className="bg-white rounded-lg px-6 py-3 shadow-xl">
                <p className="text-green-600 font-black text-2xl">🔥 128 PESSOAS</p>
                <p className="text-gray-700 text-sm font-bold">VENDO AGORA</p>
              </div>
            </div>
            <p className="text-white font-bold text-sm md:text-base mt-4 animate-pulse">
              ⏰ ATENÇÃO: Estoque limitado! Últimas unidades com desconto especial
            </p>
          </div>
        </div>
      </section>

      {/* Benefícios */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl md:text-4xl font-black text-center text-gray-900 mb-8">
            ✨ Por Que Escolher a Porta Feliz?
          </h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            <div className="benefit-card">
              <Ruler size={48} className="mx-auto mb-4 text-blue-600" />
              <h4 className="font-bold text-lg mb-2">Medidas Precisas</h4>
              <p className="text-gray-600 text-sm">
                Painéis verticais 0,85x2,10 com corte laser. Ideal para portas de 0,80x2,10.
              </p>
            </div>

            <div className="benefit-card">
              <Sparkles size={48} className="mx-auto mb-4 text-purple-600" />
              <h4 className="font-bold text-lg mb-2">Tecido Premium</h4>
              <p className="text-gray-600 text-sm">
                Malha New que não amassa, não desbota, tem leve elasticidade e alta durabilidade.
              </p>
            </div>

            <div className="benefit-card">
              <Zap size={48} className="mx-auto mb-4 text-orange-600" />
              <h4 className="font-bold text-lg mb-2">Instalação Fácil</h4>
              <p className="text-gray-600 text-sm">
                Encaixe rápido com elástico superior e inferior. Pronto em minutos.
              </p>
            </div>

            <div className="benefit-card">
              <Scissors size={48} className="mx-auto mb-4 text-green-600" />
              <h4 className="font-bold text-lg mb-2">Acabamento Profissional</h4>
              <p className="text-gray-600 text-sm">
                Corte a laser, sem emendas, sem reflexo e com caimento perfeito.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Selo de Segurança */}
      <section className="py-12 bg-gradient-to-r from-green-600 to-green-700">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h3 className="text-2xl md:text-3xl font-black text-center text-white mb-8">
              🔒 Compra 100% Segura e Protegida
            </h3>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white rounded-xl p-6 text-center shadow-lg">
                <Lock size={48} className="mx-auto mb-3 text-green-600" />
                <h4 className="font-bold mb-2">SSL Certificado</h4>
                <p className="text-sm text-gray-600">Seus dados protegidos com criptografia de ponta</p>
              </div>

              <div className="bg-white rounded-xl p-6 text-center shadow-lg">
                <Shield size={48} className="mx-auto mb-3 text-blue-600" />
                <h4 className="font-bold mb-2">Compra Protegida</h4>
                <p className="text-sm text-gray-600">Garantia de reembolso em caso de problemas</p>
              </div>

              <div className="bg-white rounded-xl p-6 text-center shadow-lg">
                <Award size={48} className="mx-auto mb-3 text-yellow-600" />
                <h4 className="font-bold mb-2">Loja Verificada</h4>
                <p className="text-sm text-gray-600">Mais de 5.000 clientes satisfeitos</p>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 text-center shadow-lg">
              <div className="flex flex-wrap justify-center items-center gap-6">
                <div className="flex items-center gap-2">
                  <CheckCircle className="text-green-600" size={24} />
                  <span className="font-bold text-gray-800">Site Seguro</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="text-green-600" size={24} />
                  <span className="font-bold text-gray-800">Dados Protegidos</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="text-green-600" size={24} />
                  <span className="font-bold text-gray-800">Entrega Rastreada</span>
                </div>
              </div>
              <p className="text-sm text-gray-600 mt-4">
                🏆 Empresa brasileira registrada • CNPJ verificado • Política de troca transparente
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section className="py-12 bg-gradient-to-b from-green-50 to-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl md:text-4xl font-black text-center text-gray-900 mb-4">
            ⭐ O Que Nossos Clientes Dizem
          </h3>
          <p className="text-center text-gray-600 mb-4 text-lg">Mais de 5.000 casas decoradas em todo Brasil!</p>
          <div className="flex justify-center items-center gap-2 mb-10">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} fill="currentColor" size={20} />
              ))}
            </div>
            <span className="font-bold text-gray-800 text-xl">4.9/5.0</span>
            <span className="text-gray-600">(2.847 avaliações)</span>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <div className="whatsapp-testimonial">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center text-white font-bold text-lg">
                  MS
                </div>
                <div className="ml-3">
                  <p className="font-bold text-gray-900">Maria Silva</p>
                  <div className="flex text-yellow-400">
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                  </div>
                </div>
              </div>
              <div className="mb-3">
                <img
                  src="https://down-br.img.susercontent.com/file/br-11134103-7r98o-m41u8dc5y8tx59.webp"
                  alt="Produto instalado na porta"
                  className="w-full rounded-xl object-cover"
                />
              </div>
              <div className="bg-gray-50 rounded-lg p-3 mb-2">
                <p className="text-gray-700 text-sm font-medium">
                  "Ficou PERFEITO na minha porta! Todo mundo que passa aqui tira foto 📸 Instalei sozinha em 5 minutos. Amei demais! ❤️"
                </p>
              </div>
              <p className="text-xs text-gray-400 flex items-center gap-1">
                <CheckCircle size={12} className="text-green-500" />
                Compra Verificada • São Paulo, SP • 2 dias atrás
              </p>
            </div>

            <div className="whatsapp-testimonial">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-bold text-lg">
                  JO
                </div>
                <div className="ml-3">
                  <p className="font-bold text-gray-900">João Oliveira</p>
                  <div className="flex text-yellow-400">
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                  </div>
                </div>
              </div>
              <div className="mb-3">
                <img
                  src="https://down-br.img.susercontent.com/file/br-11134103-81z1k-mgqeel7a9153e9.webp"
                  alt="Produto instalado na porta"
                  className="w-full rounded-xl object-cover"
                />
              </div>
              <div className="bg-gray-50 rounded-lg p-3 mb-2">
                <p className="text-gray-700 text-sm font-medium">
                  "Material muito bom! Achei que ia ser fininho mas é resistente mesmo. Minha esposa adorou o modelo do Papai Noel 🎅"
                </p>
              </div>
              <p className="text-xs text-gray-400 flex items-center gap-1">
                <CheckCircle size={12} className="text-green-500" />
                Compra Verificada • Rio de Janeiro, RJ • 1 semana atrás
              </p>
            </div>

            <div className="whatsapp-testimonial">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center text-white font-bold text-lg">
                  AC
                </div>
                <div className="ml-3">
                  <p className="font-bold text-gray-900">Ana Costa</p>
                  <div className="flex text-yellow-400">
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                    <Star fill="currentColor" size={14} />
                  </div>
                </div>
              </div>
              <div className="mb-3">
                <img
                  src="https://down-br.img.susercontent.com/file/br-11134103-81z1k-mgp4kfgyd9mo91.webp"
                  alt="Produto instalado na porta"
                  className="w-full rounded-xl object-cover"
                />
              </div>
              <div className="bg-gray-50 rounded-lg p-3 mb-2">
                <p className="text-gray-700 text-sm font-medium">
                  "Chegou super rápido! Comprei 2, uma pra mim e outra pra minha mãe. A casa ficou com clima de Natal de verdade! 🎄✨"
                </p>
              </div>
              <p className="text-xs text-gray-400 flex items-center gap-1">
                <CheckCircle size={12} className="text-green-500" />
                Compra Verificada • Belo Horizonte, MG • 3 dias atrás
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 bg-gradient-to-r from-red-600 to-green-600">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-3xl md:text-5xl font-black text-white mb-4">
              Não Perca Essa Oportunidade!
            </h3>
            <p className="text-xl text-white mb-8">
              Milhares de brasileiros já estão decorando suas portas. Garanta a sua agora!
            </p>
          </div>

          <div className="bg-gradient-to-r from-red-600 to-green-600 rounded-2xl p-8 max-w-3xl mx-auto text-center text-white mb-8">
            <p className="text-3xl font-black mb-4">⏰ PROMOÇÃO POR TEMPO LIMITADO!</p>
            <p className="text-xl mb-6">Aproveite enquanto temos estoque</p>
            <button
              onClick={scrollToModels}
              className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-black text-xl px-12 py-4 rounded-full shadow-xl transform hover:scale-105 transition-all w-full md:w-auto"
            >
              GARANTIR MINHA PORTA FELIZ AGORA!
            </button>
          </div>
        </div>
      </section>

      {/* FAQ Rápido */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl md:text-4xl font-black text-center text-gray-900 mb-10">
            ❓ Perguntas Frequentes
          </h3>

          <div className="max-w-3xl mx-auto space-y-4">
            <div className="bg-white rounded-xl p-6 shadow-md">
              <h4 className="font-bold text-lg mb-2 text-gray-900">📦 Quanto tempo demora pra chegar?</h4>
              <p className="text-gray-700">Enviamos em até 24h após a confirmação do pagamento. O prazo de entrega é de 7 a 15 dias úteis para todo Brasil via Correios com código de rastreio.</p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-md">
              <h4 className="font-bold text-lg mb-2 text-gray-900">💳 Quais formas de pagamento aceitam?</h4>
              <p className="text-gray-700">Aceitamos PIX (aprovação instantânea), cartão de crédito em até 12x, e boleto bancário. Todos os pagamentos são 100% seguros.</p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-md">
              <h4 className="font-bold text-lg mb-2 text-gray-900">📏 Serve na minha porta?</h4>
              <p className="text-gray-700">Sim! A capa mede 200cm de altura x 90cm de largura e se adapta perfeitamente em portas de 80cm a 90cm. Funciona em portas de madeira, metal e PVC.</p>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-md">
              <h4 className="font-bold text-lg mb-2 text-gray-900">🔄 E se eu não gostar?</h4>
              <p className="text-gray-700">Você tem 7 dias para trocar ou devolver sem custo adicional, conforme o Código de Defesa do Consumidor. Sua satisfação é garantida!</p>
            </div>
          </div>

          <div className="text-center mt-10">
            <button
              onClick={scrollToModels}
              className="cta-button max-w-md mx-auto"
            >
              QUERO MINHA PORTA FELIZ AGORA!
            </button>
          </div>
        </div>
      </section>

      {/* Modal de Checkout */}
      {showCheckoutForm && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[95vh] overflow-y-auto relative shadow-2xl">
            <div className="sticky top-0 bg-gradient-to-r from-green-600 to-green-700 text-white p-6 rounded-t-3xl z-10 shadow-lg">
              <button
                onClick={() => setShowCheckoutForm(false)}
                className="absolute top-4 right-4 text-white hover:text-gray-200 z-20 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full p-2 transition-colors"
              >
                <X size={24} />
              </button>
              <div className="text-center">
                <h3 className="text-2xl md:text-3xl font-black mb-3">
                  Preencha suas informações de envio.
                </h3>
                <p className="text-sm mt-2 opacity-90">Últimas unidades! não gere o pedido por curiosidade, isso reserva o produto no estoque e impede outra pessoa de comprar.</p>
              </div>
            </div>

            <div className="p-6 md:p-8">
              <form onSubmit={handleFormSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-bold text-gray-800 mb-2">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                    placeholder="João Silva"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-800 mb-2">
                      Telefone/WhatsApp *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '');
                        let formatted = value;
                        if (value.length > 0) {
                          if (value.length <= 2) {
                            formatted = `(${value}`;
                          } else if (value.length <= 7) {
                            formatted = `(${value.slice(0, 2)}) ${value.slice(2)}`;
                          } else if (value.length <= 11) {
                            formatted = `(${value.slice(0, 2)}) ${value.slice(2, 7)}-${value.slice(7)}`;
                          } else {
                            formatted = `(${value.slice(0, 2)}) ${value.slice(2, 7)}-${value.slice(7, 11)}`;
                          }
                        }
                        setFormData({ ...formData, phone: formatted });
                      }}
                      maxLength={15}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                      placeholder="(11) 98765-4321"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-800 mb-2">
                      CPF *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.cpf}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '');
                        let formatted = value;
                        if (value.length > 0) {
                          if (value.length <= 3) {
                            formatted = value;
                          } else if (value.length <= 6) {
                            formatted = `${value.slice(0, 3)}.${value.slice(3)}`;
                          } else if (value.length <= 9) {
                            formatted = `${value.slice(0, 3)}.${value.slice(3, 6)}.${value.slice(6)}`;
                          } else {
                            formatted = `${value.slice(0, 3)}.${value.slice(3, 6)}.${value.slice(6, 9)}-${value.slice(9, 11)}`;
                          }
                        }
                        setFormData({ ...formData, cpf: formatted });
                      }}
                      maxLength={14}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                      placeholder="123.456.789-00"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-800 mb-2">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                    placeholder="seuemail@exemplo.com"
                  />
                </div>

                <div className="border-t-2 border-gray-100 pt-5">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-2xl">📍</span>
                    <h4 className="font-black text-xl text-gray-900">Endereço de Entrega</h4>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4 mb-4">
                    <div className="md:col-span-1">
                      <label className="block text-sm font-bold text-gray-800 mb-2">
                        CEP *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.cep}
                        onChange={(e) => setFormData({ ...formData, cep: e.target.value })}
                        onBlur={handleCepBlur}
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                        placeholder="12345-678"
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-bold text-gray-800 mb-2">
                      Endereço *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                      placeholder="Rua, Avenida..."
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">
                        Número *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.number}
                        onChange={(e) => setFormData({ ...formData, number: e.target.value })}
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                        placeholder="123"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">
                        Complemento
                      </label>
                      <input
                        type="text"
                        value={formData.complement}
                        onChange={(e) => setFormData({ ...formData, complement: e.target.value })}
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                        placeholder="Apto, Bloco..."
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-bold text-gray-800 mb-2">
                      Bairro *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.neighborhood}
                      onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                      placeholder="Centro"
                    />
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="md:col-span-2">
                      <label className="block text-sm font-bold text-gray-800 mb-2">
                        Cidade *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                        placeholder="São Paulo"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-gray-800 mb-2">
                        Estado *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.state}
                        onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                        className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition-colors bg-gray-50 focus:bg-white"
                        placeholder="SP"
                        maxLength={2}
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-yellow-50 to-orange-50 border-2 border-yellow-400 rounded-2xl p-6 mt-6 shadow-md">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-gray-800">
                      <span className="font-bold">{selectedProducts.length}x Produto(s):</span>
                      <span className="font-bold">R$ {(selectedProducts.length * 24.90).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center text-gray-800">
                      <span className="font-bold">Frete:</span>
                      <span className="font-bold">R$ 9,90</span>
                    </div>
                    <div className="border-t-2 border-yellow-500 pt-3 mt-3">
                      <div className="flex justify-between items-center">
                        <span className="font-black text-xl text-gray-900">TOTAL:</span>
                        <span className="font-black text-3xl text-green-600">
                          R$ {((selectedProducts.length * 24.90) + 9.90).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isProcessingPayment}
                  className="w-full bg-gradient-to-r from-green-500 via-green-600 to-green-500 hover:from-green-600 hover:via-green-700 hover:to-green-600 text-white font-black text-xl py-5 rounded-2xl shadow-xl transform hover:scale-105 transition-all mt-6 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isProcessingPayment ? 'PROCESSANDO...' : 'CONTINUAR 🎄'}
                </button>

                <div className="mt-6 space-y-4">
                  <div className="flex items-center justify-center gap-2 text-gray-600 text-sm">
                    <Lock size={16} />
                    <span>Seus dados estão seguros e protegidos</span>
                  </div>

                  <div className="flex flex-wrap items-center justify-center gap-4">
                    <div className="flex items-center gap-2 bg-green-50 px-4 py-2 rounded-lg border border-green-200">
                      <ShieldCheck size={20} className="text-green-600" />
                      <span className="text-xs font-bold text-green-700">SSL Seguro</span>
                    </div>
                    <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-lg border border-blue-200">
                      <Shield size={20} className="text-blue-600" />
                      <span className="text-xs font-bold text-blue-700">Dados Criptografados</span>
                    </div>
                    <div className="flex items-center gap-2 bg-purple-50 px-4 py-2 rounded-lg border border-purple-200">
                      <Award size={20} className="text-purple-600" />
                      <span className="text-xs font-bold text-purple-700">Loja Verificada</span>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Upsell */}

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-10">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-black mb-2">🎄 PORTA FELIZ</h3>
              <p className="text-gray-400 mb-4">Transformando portas em magia natalina desde 2020</p>

              <div className="flex flex-wrap justify-center gap-6 mb-6 text-sm">
                <div className="flex items-center gap-2">
                  <Shield size={18} className="text-green-400" />
                  <span>Compra Segura</span>
                </div>
                <div className="flex items-center gap-2">
                  <Truck size={18} className="text-green-400" />
                  <span>Entrega em Todo Brasil</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star size={18} className="text-green-400" />
                  <span>+5.000 Clientes</span>
                </div>
              </div>
            </div>

            <div className="border-t border-gray-700 pt-6 text-center">
              <p className="text-sm text-gray-400 mb-2">
                <strong>Porta Feliz</strong>
              </p>
              <p className="text-sm text-gray-400 mb-4">
                CNPJ: 11.993.468/0001-40 • Atendimento: contato@portafeliz.com
              </p>

              <div className="flex flex-wrap justify-center gap-4 text-xs text-gray-500 mb-4">
                <a href="#" className="hover:text-white transition-colors">Política de Privacidade</a>
                <span>•</span>
                <a href="#" className="hover:text-white transition-colors">Termos de Uso</a>
                <span>•</span>
                <a href="#" className="hover:text-white transition-colors">Política de Troca e Devolução</a>
                <span>•</span>
                <a href="#" className="hover:text-white transition-colors">Rastreio de Pedidos</a>
              </div>

              <p className="text-xs text-gray-600">
                © 2025 Porta Feliz. Todos os direitos reservados. | Site 100% seguro e criptografado
              </p>
              <p className="text-xs text-gray-600 mt-2">
                🏆 Empresa brasileira • ✅ Nota fiscal em todas as compras • 🔒 Dados protegidos por SSL
              </p>
            </div>
          </div>
        </div>
      </footer>

      {showPixPayment && pixData && (
        <PixPayment
          pixData={pixData}
          customer={{
            name: formData.name,
            email: formData.email
          }}
          products={selectedProducts}
          onClose={() => {
            setShowPixPayment(false);
            setSelectedProducts([]);
            setFormData({
              name: '',
              phone: '',
              email: '',
              cpf: '',
              cep: '',
              address: '',
              number: '',
              complement: '',
              neighborhood: '',
              city: '',
              state: ''
            });
          }}
        />
      )}

      {showLoginModal && (
        <LoginModal
          onClose={() => setShowLoginModal(false)}
          onLogin={(cpf) => {
            setUserCpf(cpf);
            setIsLoggedIn(true);
            setShowLoginModal(false);

            if (cpf === ADMIN_CPF) {
              setIsAdmin(true);
              setShowAdminDashboard(true);
            } else {
              setIsAdmin(false);
              setShowUserDashboard(true);
            }
          }}
        />
      )}

      {showUserDashboard && isLoggedIn && !isAdmin && (
        <UserDashboard
          cpf={userCpf}
          onClose={() => setShowUserDashboard(false)}
          onLogout={() => {
            setIsLoggedIn(false);
            setUserCpf('');
            setIsAdmin(false);
            setShowUserDashboard(false);
          }}
        />
      )}

      {showAdminDashboard && isLoggedIn && isAdmin && (
        <AdminDashboard
          onClose={() => setShowAdminDashboard(false)}
          onLogout={() => {
            setIsLoggedIn(false);
            setUserCpf('');
            setIsAdmin(false);
            setShowAdminDashboard(false);
          }}
        />
      )}
    </div>
  );
}

export default App;
