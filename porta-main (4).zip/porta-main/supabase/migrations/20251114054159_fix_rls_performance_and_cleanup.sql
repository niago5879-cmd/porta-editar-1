/*
  # Fix RLS Performance and Database Cleanup

  1. Security Improvements
    - Optimize RLS policies to use `(select current_setting())` instead of `current_setting()` for better performance
    - This prevents re-evaluation of the setting for each row

  2. Database Cleanup
    - Remove unused index `idx_orders_transaction_id`
    - Fix function search path for `update_updated_at_column`

  3. Changes
    - Drop and recreate all RLS policies with optimized queries
    - Drop unused index
    - Update function with proper search path (using CASCADE to handle dependencies)
*/

-- Drop existing RLS policies
DROP POLICY IF EXISTS "Customers can view own data by CPF" ON public.customers;
DROP POLICY IF EXISTS "Customers can view own orders" ON public.orders;
DROP POLICY IF EXISTS "Customers can view own order items" ON public.order_items;
DROP POLICY IF EXISTS "Customers can view own shipping addresses" ON public.shipping_addresses;

-- Recreate optimized RLS policies for customers
CREATE POLICY "Customers can view own data by CPF"
  ON public.customers
  FOR SELECT
  TO authenticated
  USING (cpf = (select current_setting('app.current_user_cpf', true)));

-- Recreate optimized RLS policies for orders
CREATE POLICY "Customers can view own orders"
  ON public.orders
  FOR SELECT
  TO authenticated
  USING (
    customer_id IN (
      SELECT id FROM public.customers
      WHERE cpf = (select current_setting('app.current_user_cpf', true))
    )
  );

-- Recreate optimized RLS policies for order_items
CREATE POLICY "Customers can view own order items"
  ON public.order_items
  FOR SELECT
  TO authenticated
  USING (
    order_id IN (
      SELECT o.id
      FROM public.orders o
      JOIN public.customers c ON c.id = o.customer_id
      WHERE c.cpf = (select current_setting('app.current_user_cpf', true))
    )
  );

-- Recreate optimized RLS policies for shipping_addresses
CREATE POLICY "Customers can view own shipping addresses"
  ON public.shipping_addresses
  FOR SELECT
  TO authenticated
  USING (
    order_id IN (
      SELECT o.id
      FROM public.orders o
      JOIN public.customers c ON c.id = o.customer_id
      WHERE c.cpf = (select current_setting('app.current_user_cpf', true))
    )
  );

-- Remove unused index
DROP INDEX IF EXISTS public.idx_orders_transaction_id;

-- Fix function search path (use CASCADE to handle dependent triggers)
DROP FUNCTION IF EXISTS public.update_updated_at_column() CASCADE;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Recreate the triggers that were dropped by CASCADE
CREATE TRIGGER update_customers_updated_at
  BEFORE UPDATE ON public.customers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();