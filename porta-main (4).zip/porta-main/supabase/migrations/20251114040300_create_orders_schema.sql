/*
  # Create Orders and Customers Schema

  ## Overview
  This migration creates the complete schema for managing customer orders, including
  order tracking, customer information, and product details for the Porta Feliz e-commerce.

  ## New Tables

  ### `customers`
  - `id` (uuid, primary key) - Unique customer identifier
  - `cpf` (text, unique, indexed) - Customer CPF for login authentication
  - `name` (text) - Full customer name
  - `email` (text) - Customer email address
  - `phone` (text) - Customer phone/WhatsApp number
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Record last update timestamp

  ### `orders`
  - `id` (uuid, primary key) - Unique order identifier
  - `customer_id` (uuid, foreign key) - Reference to customers table
  - `transaction_id` (text, unique) - Payment gateway transaction ID
  - `status` (text) - Order status: pending, paid, processing, shipped, delivered, cancelled
  - `amount` (integer) - Total order amount in cents
  - `subtotal` (integer) - Subtotal before shipping in cents
  - `shipping_fee` (integer) - Shipping cost in cents
  - `payment_method` (text) - Payment method used (pix, credit_card, etc)
  - `tracking_code` (text) - Shipping tracking code
  - `pix_qrcode` (text) - PIX QR code for payment
  - `pix_expiration` (timestamptz) - PIX payment expiration date
  - `created_at` (timestamptz) - Order creation timestamp
  - `updated_at` (timestamptz) - Order last update timestamp
  - `paid_at` (timestamptz) - Payment confirmation timestamp

  ### `order_items`
  - `id` (uuid, primary key) - Unique item identifier
  - `order_id` (uuid, foreign key) - Reference to orders table
  - `product_id` (text) - Product identifier
  - `product_name` (text) - Product name at time of purchase
  - `quantity` (integer) - Quantity ordered
  - `unit_price` (integer) - Unit price in cents
  - `created_at` (timestamptz) - Record creation timestamp

  ### `shipping_addresses`
  - `id` (uuid, primary key) - Unique address identifier
  - `order_id` (uuid, foreign key) - Reference to orders table
  - `cep` (text) - Brazilian postal code
  - `address` (text) - Street address
  - `number` (text) - Address number
  - `complement` (text) - Additional address info
  - `neighborhood` (text) - Neighborhood/district
  - `city` (text) - City name
  - `state` (text) - State abbreviation
  - `created_at` (timestamptz) - Record creation timestamp

  ## Security
  - Row Level Security (RLS) is enabled on all tables
  - Customers can only view their own data using CPF authentication
  - No public access - all data is protected by default

  ## Indexes
  - CPF index for fast customer lookups
  - Transaction ID index for payment tracking
  - Customer ID indexes for efficient joins
  - Order ID indexes for related data queries

  ## Important Notes
  - All monetary values are stored in cents to avoid floating-point precision issues
  - CPF is used as the authentication key for customer login
  - Order status follows a clear lifecycle: pending → paid → processing → shipped → delivered
  - Tracking codes are nullable until the order is shipped
*/

-- Create customers table
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cpf text UNIQUE NOT NULL,
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create index on CPF for fast lookups
CREATE INDEX IF NOT EXISTS idx_customers_cpf ON customers(cpf);

-- Enable RLS on customers
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;

-- Customers can view their own data by CPF
CREATE POLICY "Customers can view own data by CPF"
  ON customers FOR SELECT
  USING (cpf = current_setting('app.current_user_cpf', true));

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  transaction_id text UNIQUE,
  status text NOT NULL DEFAULT 'pending',
  amount integer NOT NULL,
  subtotal integer NOT NULL,
  shipping_fee integer NOT NULL DEFAULT 990,
  payment_method text NOT NULL DEFAULT 'pix',
  tracking_code text,
  pix_qrcode text,
  pix_expiration timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  paid_at timestamptz
);

-- Create index on customer_id for fast lookups
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_transaction_id ON orders(transaction_id);

-- Enable RLS on orders
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Customers can view their own orders
CREATE POLICY "Customers can view own orders"
  ON orders FOR SELECT
  USING (
    customer_id IN (
      SELECT id FROM customers 
      WHERE cpf = current_setting('app.current_user_cpf', true)
    )
  );

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id text NOT NULL,
  product_name text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  unit_price integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create index on order_id for fast lookups
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);

-- Enable RLS on order_items
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

-- Customers can view their own order items
CREATE POLICY "Customers can view own order items"
  ON order_items FOR SELECT
  USING (
    order_id IN (
      SELECT o.id FROM orders o
      JOIN customers c ON c.id = o.customer_id
      WHERE c.cpf = current_setting('app.current_user_cpf', true)
    )
  );

-- Create shipping_addresses table
CREATE TABLE IF NOT EXISTS shipping_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  cep text NOT NULL,
  address text NOT NULL,
  number text NOT NULL,
  complement text,
  neighborhood text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create index on order_id for fast lookups
CREATE INDEX IF NOT EXISTS idx_shipping_addresses_order_id ON shipping_addresses(order_id);

-- Enable RLS on shipping_addresses
ALTER TABLE shipping_addresses ENABLE ROW LEVEL SECURITY;

-- Customers can view their own shipping addresses
CREATE POLICY "Customers can view own shipping addresses"
  ON shipping_addresses FOR SELECT
  USING (
    order_id IN (
      SELECT o.id FROM orders o
      JOIN customers c ON c.id = o.customer_id
      WHERE c.cpf = current_setting('app.current_user_cpf', true)
    )
  );

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_customers_updated_at'
  ) THEN
    CREATE TRIGGER update_customers_updated_at
      BEFORE UPDATE ON customers
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_orders_updated_at'
  ) THEN
    CREATE TRIGGER update_orders_updated_at
      BEFORE UPDATE ON orders
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;