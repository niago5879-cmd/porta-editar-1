import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const body = await req.json();
    const { amount, customer, items } = body;

    console.log('Dados recebidos:', { amount, customer, items });

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const publicKey = 'pk_T025H2g08STIXyK9MY0h2yL4XnxS2-AKBg5HJQGpbsF7G96M';
    const secretKey = 'sk_-xihPLTZ5ZIwsPkOu-tktgnYeWoR3puwX8xtAHCPUidBYBGP';
    const auth = 'Basic ' + btoa(publicKey + ':' + secretKey);

    const baseNumber = '176307';
    const randomSuffix = Math.floor(Math.random() * 100000).toString().padStart(5, '0');
    const randomProductId = baseNumber + randomSuffix;

    const payload = {
      amount: amount,
      currency: 'BRL',
      paymentMethod: 'pix',
      installments: 1,
      customer: {
        name: customer.name,
        email: customer.email,
        phone: customer.phone.replace(/\D/g, ''),
        document: {
          type: 'cpf',
          number: customer.cpf.replace(/\D/g, '')
        }
      },
      card: {},
      pix: {},
      boleto: {},
      shipping: {
        fee: 0,
        address: {
          street: customer.address,
          streetNumber: customer.number,
          complement: customer.complement || '',
          zipCode: customer.cep.replace(/\D/g, ''),
          neighborhood: customer.neighborhood,
          city: customer.city,
          state: customer.state,
          country: 'BR'
        }
      },
      items: items.map((item: any) => ({
        title: randomProductId,
        quantity: 1,
        tangible: true,
        unitPrice: 2490
      }))
    };

    console.log('Payload enviado:', JSON.stringify(payload, null, 2));

    const response = await fetch('https://api.hawkpaydigital.com/v1/transactions', {
      method: 'POST',
      headers: {
        Authorization: auth,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    console.log('Resposta da API:', { status: response.status, data });

    if (!response.ok) {
      console.error('Erro da API HawkPay:', data);
      throw new Error(JSON.stringify(data) || 'Erro ao criar pagamento PIX');
    }

    const cleanCpf = customer.cpf.replace(/\D/g, '');

    let customerRecord = await supabase
      .from('customers')
      .select('id')
      .eq('cpf', cleanCpf)
      .maybeSingle();

    let customerId: string;

    if (!customerRecord.data) {
      const newCustomer = await supabase
        .from('customers')
        .insert({
          cpf: cleanCpf,
          name: customer.name,
          email: customer.email,
          phone: customer.phone
        })
        .select('id')
        .single();

      if (newCustomer.error) {
        console.error('Erro ao criar cliente:', newCustomer.error);
        throw new Error('Erro ao salvar dados do cliente');
      }

      customerId = newCustomer.data.id;
    } else {
      customerId = customerRecord.data.id;
    }

    const subtotal = items.length * 2490;
    const shippingFee = 990;

    const orderResult = await supabase
      .from('orders')
      .insert({
        customer_id: customerId,
        transaction_id: data.id,
        status: 'pending',
        amount: amount,
        subtotal: subtotal,
        shipping_fee: shippingFee,
        payment_method: 'pix',
        pix_qrcode: data.pix?.qrcode || null,
        pix_qrcode_text: data.pix?.qrcodeText || null,
        pix_expiration: data.pix?.expirationDate || null
      })
      .select('id')
      .single();

    if (orderResult.error) {
      console.error('Erro ao criar pedido:', orderResult.error);
      throw new Error('Erro ao salvar pedido');
    }

    const orderId = orderResult.data.id;

    const orderItems = items.map((item: any) => ({
      order_id: orderId,
      product_id: item.id,
      product_name: item.name,
      quantity: 1,
      unit_price: 2490
    }));

    const itemsResult = await supabase
      .from('order_items')
      .insert(orderItems);

    if (itemsResult.error) {
      console.error('Erro ao criar itens do pedido:', itemsResult.error);
    }

    const addressResult = await supabase
      .from('shipping_addresses')
      .insert({
        order_id: orderId,
        cep: customer.cep,
        address: customer.address,
        number: customer.number,
        complement: customer.complement || null,
        neighborhood: customer.neighborhood,
        city: customer.city,
        state: customer.state
      });

    if (addressResult.error) {
      console.error('Erro ao criar endereço:', addressResult.error);
    }

    return new Response(JSON.stringify(data), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
      },
    });
  } catch (error) {
    console.error('Erro na requisição:', error);
    return new Response(
      JSON.stringify({
        error: error.message || 'Erro ao processar pagamento',
        details: error.toString()
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});