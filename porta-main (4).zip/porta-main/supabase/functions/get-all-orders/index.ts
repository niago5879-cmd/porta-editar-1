import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { data: orders, error: ordersError } = await supabase
      .from('orders')
      .select(`
        id,
        transaction_id,
        status,
        amount,
        subtotal,
        shipping_fee,
        tracking_code,
        tracking_url,
        pix_qrcode,
        pix_expiration,
        created_at,
        paid_at,
        customer_id,
        customers (
          name,
          email,
          phone,
          cpf
        ),
        order_items (
          product_id,
          product_name,
          quantity,
          unit_price
        ),
        shipping_addresses (
          address,
          number,
          complement,
          neighborhood,
          city,
          state,
          cep
        )
      `)
      .order('created_at', { ascending: false });

    if (ordersError) {
      console.error('Erro ao buscar pedidos:', ordersError);
      return new Response(
        JSON.stringify({ error: 'Erro ao buscar pedidos' }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const formattedOrders = orders.map((order: any) => ({
      id: order.id,
      transaction_id: order.transaction_id,
      status: order.status,
      amount: order.amount,
      subtotal: order.subtotal,
      shipping_fee: order.shipping_fee,
      tracking_code: order.tracking_code,
      tracking_url: order.tracking_url,
      pix_qrcode: order.pix_qrcode,
      pix_expiration: order.pix_expiration,
      created_at: order.created_at,
      paid_at: order.paid_at,
      items: order.order_items || [],
      shipping_address: order.shipping_addresses?.[0] || null,
      customer: {
        name: order.customers?.name || '',
        email: order.customers?.email || '',
        phone: order.customers?.phone || '',
        cpf: order.customers?.cpf || ''
      }
    }));

    return new Response(
      JSON.stringify({ orders: formattedOrders }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Erro ao buscar pedidos:', error);
    return new Response(
      JSON.stringify({
        error: error.message || 'Erro ao processar requisição',
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});