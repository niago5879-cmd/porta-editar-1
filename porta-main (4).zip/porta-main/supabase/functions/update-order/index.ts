import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const body = await req.json();
    const { order_id, tracking_code, tracking_url, status } = body;

    if (!order_id) {
      return new Response(
        JSON.stringify({ error: 'order_id é obrigatório' }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const updateData: any = {};

    if (tracking_code !== undefined) {
      updateData.tracking_code = tracking_code;
      if (tracking_code && tracking_code.trim()) {
        updateData.status = 'shipped';
      }
    }

    if (tracking_url !== undefined) {
      updateData.tracking_url = tracking_url;
    }

    if (status !== undefined) {
      updateData.status = status;
      if (status === 'paid' && !updateData.paid_at) {
        const { data: currentOrder } = await supabase
          .from('orders')
          .select('paid_at')
          .eq('id', order_id)
          .single();

        if (!currentOrder?.paid_at) {
          updateData.paid_at = new Date().toISOString();
        }
      }
    }

    const { data, error } = await supabase
      .from('orders')
      .update(updateData)
      .eq('id', order_id)
      .select()
      .single();

    if (error) {
      console.error('Erro ao atualizar pedido:', error);
      return new Response(
        JSON.stringify({ error: 'Erro ao atualizar pedido' }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    return new Response(
      JSON.stringify({ success: true, order: data }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Erro ao processar requisição:', error);
    return new Response(
      JSON.stringify({
        error: error.message || 'Erro ao processar requisição',
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});